# NEXT STEP

Do not add Wine or BoxedWine back into this project.

After confirming this IPA opens on the iPhone, the next engineering task is
to inspect the user's legally owned POSTAL 2 installation and identify the
map, texture, mesh, animation and UnrealScript package formats that must be
converted or parsed.

Goal of milestone 2:
- one real POSTAL 2 environment rendered on iPhone
- camera movement
- touch movement
- FPS counter
- target 60 FPS
