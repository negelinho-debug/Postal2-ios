# POSTAL 2 iOS — Native ARM64 Starter

This is the clean native baseline for the POSTAL 2 iOS port.

## What it already does

- Native iPhone ARM64 build
- Metal render loop
- 60 FPS target
- Landscape mode
- Placeholder touch controls
- GitHub Actions build
- Produces an unsigned `.ipa`

## What it does NOT do yet

It does not run `Postal2.exe`, Wine, BoxedWine, Box64, or any x86 emulator.
It also does not contain POSTAL 2 game assets or proprietary files.

## Build from GitHub

1. Upload all files in this folder to a GitHub repository.
2. Open **Actions**.
3. Choose **Build POSTAL 2 Native iOS**.
4. Tap **Run workflow**.
5. When the run finishes, download artifact:
   `Postal2Native-unsigned-IPA`
6. Sign the IPA with your normal sideloading/signing method.

## Next port milestone

The next milestone is to replace the empty Metal scene with:
1. real POSTAL 2 map/mesh loading,
2. Dude camera + movement,
3. textures,
4. collision,
5. then weapons/NPC/game logic.

Use only game data from your own legally obtained copy.
