import SwiftUI
import MetalKit

@main
struct Postal2NativeApp: App {
    var body: some Scene {
        WindowGroup {
            GameRootView()
                .ignoresSafeArea()
        }
    }
}

struct GameRootView: View {
    var body: some View {
        ZStack(alignment: .topLeading) {
            MetalGameView()
                .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 4) {
                Text("POSTAL 2 iOS")
                    .font(.headline)
                Text("Native ARM64 / Metal / 60 FPS target")
                    .font(.caption)
            }
            .padding(10)
            .background(.black.opacity(0.55))
            .foregroundStyle(.white)
            .padding(10)

            VStack {
                Spacer()
                HStack {
                    VirtualStick()
                    Spacer()
                    HStack(spacing: 14) {
                        ActionButton(title: "USE")
                        ActionButton(title: "FIRE")
                    }
                }
                .padding(24)
            }
        }
        .background(Color.black)
    }
}

struct ActionButton: View {
    let title: String

    var body: some View {
        Text(title)
            .font(.caption.bold())
            .frame(width: 74, height: 74)
            .background(.white.opacity(0.14))
            .overlay(
                Circle().stroke(.white.opacity(0.45), lineWidth: 2)
            )
            .clipShape(Circle())
            .foregroundStyle(.white)
    }
}

struct VirtualStick: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(.white.opacity(0.10))
                .frame(width: 120, height: 120)
            Circle()
                .fill(.white.opacity(0.30))
                .frame(width: 52, height: 52)
        }
    }
}

struct MetalGameView: UIViewRepresentable {
    func makeCoordinator() -> Renderer {
        Renderer()
    }

    func makeUIView(context: Context) -> MTKView {
        guard let device = MTLCreateSystemDefaultDevice() else {
            fatalError("Metal is not available on this device")
        }

        let view = MTKView(frame: .zero, device: device)
        view.delegate = context.coordinator
        view.preferredFramesPerSecond = 60
        view.enableSetNeedsDisplay = false
        view.isPaused = false
        view.framebufferOnly = true
        view.colorPixelFormat = .bgra8Unorm
        context.coordinator.configure(device: device)

        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}
}

final class Renderer: NSObject, MTKViewDelegate {
    private var commandQueue: MTLCommandQueue?
    private var time: Float = 0

    func configure(device: MTLDevice) {
        commandQueue = device.makeCommandQueue()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

    func draw(in view: MTKView) {
        guard
            let descriptor = view.currentRenderPassDescriptor,
            let drawable = view.currentDrawable,
            let queue = commandQueue,
            let commandBuffer = queue.makeCommandBuffer()
        else { return }

        time += 1.0 / 60.0

        // Simple animated clear color so we know the Metal render loop is alive.
        let pulse = 0.025 + 0.015 * (sin(Double(time)) + 1.0)
        descriptor.colorAttachments[0].clearColor =
            MTLClearColor(red: 0.03, green: pulse, blue: 0.025, alpha: 1.0)

        if let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: descriptor) {
            encoder.endEncoding()
        }

        commandBuffer.present(drawable)
        commandBuffer.commit()
    }
}
